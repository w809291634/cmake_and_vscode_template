#ifndef TESTCLASS_H
#define TESTCLASS_H
#include<iostream>
#include<stdio.h>
 
class ValueClass
{
 
private:
    int value;
    int sum;
public:
    ValueClass();
    void Add(int i, int j);
};
 
#endif 