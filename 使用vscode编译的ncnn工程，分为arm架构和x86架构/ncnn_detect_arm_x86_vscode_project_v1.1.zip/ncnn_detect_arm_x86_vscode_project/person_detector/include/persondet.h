#pragma once
#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <map>
#include <string>
#include "net.h"
#include <stack>
#include <opencv2/opencv.hpp>
#include <chrono>

using namespace std::chrono;

class Timer
{
public:
    std::stack<high_resolution_clock::time_point> tictoc_stack;

    void tic()
    {
        high_resolution_clock::time_point t1 = high_resolution_clock::now();
        tictoc_stack.push(t1);
    }

    double toc(std::string msg = "", bool flag = true)
    {
        double diff = duration_cast<milliseconds>(high_resolution_clock::now() - tictoc_stack.top()).count();
        if(msg.size() > 0){
            if (flag)
                printf("%s time elapsed: %f ms\n", msg.c_str(), diff);
        }

        tictoc_stack.pop();
        return diff;
    }
    void reset()
    {
        tictoc_stack = std::stack<high_resolution_clock::time_point>();
    }
};


// 行人检测类
class Persondet 
{
public:
    Persondet(): person_width(320), person_height(320){}
    ~Persondet();

    int init(std::string model_path);
    int detect(cv::Mat &image);

    int person_width;
    int person_height;

private:
    ncnn::Net person_det;
};


