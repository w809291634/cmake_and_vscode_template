#pragma once
#include<vector>
#include<iostream>
#include<algorithm>
#include<numeric>
#include<map>
#include<string>
#include "net.h"
#include <opencv2/opencv.hpp>


#define FACE_FEATURE_LEN 128
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MID
#define MID(a, b, c) ((a)<(b) ? ((b)<(c)?(b):(a)<(c)?(c):(a)) : ((b)>(c)?(b):(a)>(c)?(c):(a)))
#endif

#ifndef ABS
#define ABS(a) ((a) < (0) ? -(a) : (a))
#endif

struct FaceRec{
    float data[128];
};


struct BboxFace
{
    int x1;
    int y1;
    int x2;
    int y2;
    unsigned int id;
    unsigned int score;
    float area;
    FaceRec rec;
};


class FaceFeature{
public:
    FaceFeature(){};
    float face_feature[128];
    std::string name;
};


// 人脸识别对象
class Facerec {
public:
    Facerec(): face_width(224), face_height(224), rec_width(112), rec_height(112){}
    ~Facerec();

    int init(std::string model_path);
    //You can change the shape of input image by setting params :resized_w and resized_h
    std::vector<BboxFace> recognize(cv::Mat& image, std::vector<FaceFeature> face_feats);

private:
    ncnn::Net face_det;
    ncnn::Net face_rec;

public:
    int face_width;
    int face_height;

    int rec_width;
    int rec_height;

};


