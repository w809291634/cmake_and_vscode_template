#pragma once
#include<vector>
#include<iostream>
#include<algorithm>
#include<numeric>
#include<map>
#include<string>
#include "net.h"
#include <opencv2/opencv.hpp>


// 关键点结构体
struct KeyPoint
{
    cv::Point p;
    float prob;
};


// 在图像上画出关节点
static void draw_pose(cv::Mat& image, const std::vector<KeyPoint>& keypoints)
{
    // draw bone
    static const int joint_pairs[16][2] = {
            {0, 1}, {1, 3}, {0, 2}, {2, 4}, {5, 6}, {5, 7}, {7, 9}, {6, 8}, {8, 10}, {5, 11}, {6, 12}, {11, 12}, {11, 13}, {12, 14}, {13, 15}, {14, 16}
    };
    for (int i = 0; i < 16; i++)
    {
        const KeyPoint& p1 = keypoints[joint_pairs[i][0]];
        const KeyPoint& p2 = keypoints[joint_pairs[i][1]];
        if (p1.prob < 0.2f || p2.prob < 0.2f)
            continue;
        cv::line(image, p1.p, p2.p, cv::Scalar(255, 0, 0), 2);
    }
    // draw joint
    for (size_t i = 0; i < keypoints.size(); i++)
    {
        const KeyPoint& keypoint = keypoints[i];
        //fprintf(stderr, "%.2f %.2f = %.5f\n", keypoint.p.x, keypoint.p.y, keypoint.prob);
        if (keypoint.prob < 0.2f)
            continue;
        cv::circle(image, keypoint.p, 3, cv::Scalar(0, 255, 0), -1);
    }
}


// 姿态检测对象
class Posedet {
public:
    Posedet(): person_width(320), person_height(320), pose_width(192), pose_height(256){}
    ~Posedet();

    int init(std::string model_path);

    //You can change the shape of input image by setting params :resized_w and resized_h
    int detect(cv::Mat &image);
    int runpose(cv::Mat &roi, std::vector<KeyPoint>& keypoints, float x1, float y1);


private:
    ncnn::Net person_det;
    ncnn::Net pose_det;

public:
    int person_width;
    int person_height;

    int pose_width;
    int pose_height;
};


